# 碎片库

荣鸢的私人灵感碎片库。网站程序可以公开托管，但碎片内容默认保存在使用者自己的浏览器本地，不会自动上传到这个仓库。

## 第一次发布

1. 在 GitHub 新建一个公开仓库，仓库名可用 `fragment-vault`。
2. 把本文件夹内的全部内容上传到仓库根目录，包括隐藏的 `.github` 文件夹。
3. 打开仓库 `Settings → Pages`。
4. 在 `Build and deployment` 的 `Source` 中选择 `GitHub Actions`。
5. 等待仓库顶部 `Actions` 中的“发布碎片库”完成。
6. 回到 `Settings → Pages`，点击 `Visit site`。

## 安装到安卓

使用 Chrome 打开 GitHub Pages 地址。页面出现“安装碎片库 App”时点击安装；也可以从 Chrome 菜单选择“安装应用”。

## 以后更新

把新版文件覆盖上传到同一个仓库。每次 `main` 分支更新后，GitHub Actions 会自动重新发布。手机 App 检测到新版后会显示“碎片库长出了新版本”。

## 隐私提醒

不要把从碎片库导出的备份 JSON 上传到仓库。备份中可能包含私人文字、图片、来源和 AI 点评。
